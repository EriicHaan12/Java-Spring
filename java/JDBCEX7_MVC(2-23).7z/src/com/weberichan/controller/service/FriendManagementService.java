package com.weberichan.controller.service;

import java.sql.SQLException;

public interface FriendManagementService {
	public void toDo() throws ClassNotFoundException, SQLException;
	
}
